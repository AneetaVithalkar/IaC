# vm-actions

Testing out GitHub Actions to create a virtual machine(VM) within Azure. 


## Credits

Written by: Sarah Lean

Find me on:

* My Blog: <https://www.techielass.com>
* Twitter: <https://twitter.com/techielass>
* LinkedIn: <http://uk.linkedin.com/in/sazlean>
* Github: <https://github.com/weeyin83>
